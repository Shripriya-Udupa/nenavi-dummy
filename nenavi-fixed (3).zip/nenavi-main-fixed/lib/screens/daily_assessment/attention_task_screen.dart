import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Attention task — shows the number 1239 and asks the patient to enter it.
/// The seed phrase and J-word steps are handled by separate screens now.
/// Returns [score, seedPhrase (empty), enteredNumber].
class AttentionTaskScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final Function(int score, String seedPhrase, String enteredNumber) onComplete;

  const AttentionTaskScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  State<AttentionTaskScreen> createState() => _AttentionTaskScreenState();
}

class _AttentionTaskScreenState extends State<AttentionTaskScreen> {
  late String _numberInstruction;
  late String _targetNumber;
  String _enteredNumber = '';
  bool _numberFirstAttempt = true;

  @override
  void initState() {
    super.initState();
    final lang = widget.language;
    final numberData =
        QuestionBank.numberMemory[lang] ?? QuestionBank.numberMemory['en']!;
    _numberInstruction = numberData['instruction'];
    _targetNumber = numberData['targetNumber'];
  }

  @override
  void dispose() {
    TtsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Number Entry'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (mounted)
                  widget.onComplete(0, '', _enteredNumber);
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: _buildNumberTask(),
              ),
            ),
            // Submit always visible, never pushed off by keyboard
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onPressed: () {
                  if (_enteredNumber.trim() == _targetNumber) {
                    final score = _numberFirstAttempt ? 1 : 0;
                    widget.onComplete(score, '', _enteredNumber.trim());
                  } else {
                    setState(() => _numberFirstAttempt = false);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Incorrect, try again')),
                    );
                  }
                },
                child: const Text('Submit'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumberTask() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          _numberInstruction,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        Center(
          child: PlayAudioButton(
            textToRead: _numberInstruction,
            language: widget.language,
            label: 'Read Question',
          ),
        ),
        const SizedBox(height: 32),
        TextField(
          onChanged: (v) => setState(() => _enteredNumber = v),
          keyboardType: TextInputType.phone,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            labelText: 'Type the number',
            alignLabelWithHint: true,
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}
