import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Step 1 of the assessment — patient reads/listens to the seed phrase
/// "I AM A GOOD PERSON". No scoring; just acknowledgement via Next.
class SeedPhraseScreen extends StatelessWidget {
  final String language;
  final DateTime endTime;
  final VoidCallback onComplete;

  const SeedPhraseScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    final data =
        QuestionBank.seedPhrase[language] ?? QuestionBank.seedPhrase['en']!;
    final instruction = data['instruction'] as String;
    final phrase = data['phrase'] as String;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Read Aloud'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: endTime,
              onExpire: () {
                if (context.mounted) onComplete();
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 16),
              Text(
                instruction,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Center(
                child: PlayAudioButton(
                  textToRead: '$instruction. $phrase',
                  language: language,
                  label: 'Read Aloud',
                ),
              ),
              const SizedBox(height: 40),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Text(
                  phrase,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: onComplete,
                child: const Text('Next'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
