import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Step 2 of the assessment — pick the word that starts with "J".
/// Returns the chosen word (String) so it can be shown again later
/// in the J-word recall step.
class JWordTaskScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final Function(int score, String chosenWord) onComplete;

  const JWordTaskScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  State<JWordTaskScreen> createState() => _JWordTaskScreenState();
}

class _JWordTaskScreenState extends State<JWordTaskScreen> {
  String? _selectedWord;

  late String _instruction;
  late List<String> _options;
  late String _correctWord;

  @override
  void initState() {
    super.initState();
    final data = QuestionBank.jWordTask[widget.language] ??
        QuestionBank.jWordTask['en']!;
    _instruction = data['instruction'] as String;
    _options = List<String>.from(data['options'] as List);
    _correctWord = data['correct'] as String;
  }

  @override
  void dispose() {
    TtsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Word Selection'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                final score =
                    (_selectedWord != null && _selectedWord == _correctWord)
                        ? 1
                        : 0;
                if (mounted) widget.onComplete(score, _selectedWord ?? '');
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      _instruction,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        PlayAudioButton(
                          textToRead: _instruction,
                          language: widget.language,
                          label: 'Read Question',
                        ),
                        PlayAudioButton(
                          textToRead: _options.join(', '),
                          language: widget.language,
                          label: 'Read Options',
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    // Render pairs as 2-column rows
                    for (int i = 0; i < _options.length; i += 2)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          children: [
                            _WordButton(
                              word: _options[i],
                              isSelected: _selectedWord == _options[i],
                              onTap: () =>
                                  setState(() => _selectedWord = _options[i]),
                            ),
                            const SizedBox(width: 12),
                            if (i + 1 < _options.length)
                              _WordButton(
                                word: _options[i + 1],
                                isSelected: _selectedWord == _options[i + 1],
                                onTap: () => setState(
                                    () => _selectedWord = _options[i + 1]),
                              )
                            else
                              const Expanded(child: SizedBox()),
                          ],
                        ),
                      ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: _selectedWord == null
                    ? null
                    : () {
                        final score = _selectedWord == _correctWord ? 1 : 0;
                        widget.onComplete(score, _selectedWord!);
                      },
                child: const Text('Submit'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WordButton extends StatelessWidget {
  final String word;
  final bool isSelected;
  final VoidCallback onTap;

  const _WordButton({
    required this.word,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              isSelected ? Colors.blue.shade400 : Colors.white,
          foregroundColor: isSelected ? Colors.white : Colors.black87,
          elevation: isSelected ? 2 : 1,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: isSelected
                  ? Colors.blue.shade600
                  : Colors.grey.shade300,
            ),
          ),
        ),
        onPressed: onTap,
        child: Text(
          word,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
