import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:nenavi/widgets/sos_dialog_helper.dart';

class EmergencySosService {
  static final EmergencySosService _instance =
      EmergencySosService._internal();
  static final _firestore = FirebaseFirestore.instance;
  static final _auth = FirebaseAuth.instance;

  factory EmergencySosService() {
    return _instance;
  }

  EmergencySosService._internal();

  /// Request location permissions with proper handling for all denial states
  Future<bool> requestLocationPermission() async {
    // First check via permission_handler — more reliable cross-device
    var status = await Permission.locationWhenInUse.status;

    if (status.isGranted) return true;

    if (status.isPermanentlyDenied) {
      // User has tapped "Don't allow" twice or selected "Never" —
      // the only way forward is opening App Settings directly.
      debugPrint('Location permanently denied — opening App Settings');
      await openAppSettings(); // from permission_handler
      return false;
    }

    // Not yet asked, or denied once — ask now
    status = await Permission.locationWhenInUse.request();
    if (status.isGranted) return true;

    if (status.isPermanentlyDenied) {
      debugPrint('Location permanently denied after request — opening App Settings');
      await openAppSettings();
      return false;
    }

    debugPrint('Location permission denied: $status');
    return false;
  }

  /// Check if location services are enabled
  Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// Enable location services (opens settings)
  Future<void> enableLocationServices() async {
    await Geolocator.openLocationSettings();
  }

  /// Get current location with improved error handling and retries
  Future<Position?> getCurrentLocation({int retries = 3}) async {
    try {
      // Check if location services are enabled
      final serviceEnabled = await isLocationServiceEnabled();
      if (!serviceEnabled) {
        debugPrint('Location services are disabled');
        await enableLocationServices();
        return null;
      }

      // Request permission
      final hasPermission = await requestLocationPermission();
      if (!hasPermission) {
        debugPrint('Location permission denied');
        return null;
      }

      Position? position;
      int attempts = 0;

      // Retry logic for better reliability
      while (attempts < retries) {
        try {
          position = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.best,
              distanceFilter: 0,
              timeLimit: Duration(seconds: 15), // Increased from 10 to 15
            ),
          );

          if (position != null) {
            debugPrint(
              'Location obtained: ${position.latitude}, ${position.longitude}',
            );
            return position;
          }

          attempts++;
          if (attempts < retries) {
            // Wait before retry
            await Future.delayed(const Duration(seconds: 1));
          }
        } on TimeoutException catch (e) {
          debugPrint('Timeout on attempt ${attempts + 1}: $e');
          attempts++;
          if (attempts < retries) {
            await Future.delayed(const Duration(seconds: 1));
          }
        } catch (e) {
          debugPrint('Error on attempt ${attempts + 1}: $e');
          attempts++;
          if (attempts < retries) {
            await Future.delayed(const Duration(seconds: 1));
          }
        }
      }

      debugPrint('Failed to get location after $retries attempts');
      return position;
    } catch (e) {
      debugPrint('Error getting location: $e');
      return null;
    }
  }

  /// Get location with validation
  Future<Map<String, dynamic>> getLocationWithValidation() async {
    try {
      final position = await getCurrentLocation();

      if (position != null &&
          (position.latitude != 0.0 || position.longitude != 0.0)) {
        return {
          'latitude': position.latitude,
          'longitude': position.longitude,
          'accuracy': position.accuracy,
          'altitude': position.altitude,
          'speed': position.speed,
          'timestamp': position.timestamp,
          'locationObtained': true,
          'mapUrl': 'https://maps.google.com/?q=${position.latitude},${position.longitude}',
        };
      } else {
        debugPrint('WARNING: Location is 0.0 or null - GPS may not be working');
        return {
          'latitude': null,
          'longitude': null,
          'accuracy': null,
          'altitude': null,
          'speed': null,
          'timestamp': null,
          'locationObtained': false,
          'mapUrl': null,
          'error': 'GPS location unavailable',
        };
      }
    } catch (e) {
      debugPrint('Error in location validation: $e');
      return {
        'latitude': null,
        'longitude': null,
        'accuracy': null,
        'locationObtained': false,
        'mapUrl': null,
        'error': e.toString(),
      };
    }
  }

  /// Trigger Emergency SOS Alert
  Future<String?> triggerSosAlert({required BuildContext context}) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');

      // Get patient data
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      if (!userDoc.exists) throw Exception('User data not found');

      final userData = userDoc.data() as Map<String, dynamic>;
      final patientName = userData['name'] as String? ?? 'Unknown Patient';
      final caregiverEmail = userData['caregiverEmail'] as String?;
      final patientPhone = userData['phone'] as String? ?? '';
      final emergencyData = userData['emergencyContact'] as Map?;
      final emergencyPhone = emergencyData?['phone'] as String? ?? '';

      if (caregiverEmail == null) {
        throw Exception('Caregiver not found');
      }

      // Get caregiver data
      final caregiverSnapshot = await _firestore
          .collection('caregiver_registry')
          .doc(caregiverEmail)
          .get();

      if (!caregiverSnapshot.exists) {
        throw Exception('Caregiver data not found');
      }

      final caregiverUid = caregiverSnapshot.data()?['uid'] as String?;
      if (caregiverUid == null || caregiverUid.isEmpty) {
        throw Exception('Caregiver UID not found in registry');
      }

      final caregiverPhoneData = await _firestore
          .collection('users')
          .doc(caregiverUid)
          .get();
      final caregiverPhone = caregiverPhoneData.data()?['phone'] as String? ?? '';

      // Get location with validation
      final locationData = await getLocationWithValidation();
      final latitude = locationData['latitude'] as double?;
      final longitude = locationData['longitude'] as double?;
      final locationObtained = locationData['locationObtained'] as bool;

      debugPrint(
        'SOS Location: lat=$latitude, lng=$longitude, obtained=$locationObtained',
      );

      // Create SOS alert in Firestore
      final alertRef = await _firestore.collection('sos_alerts').add({
        'patientUid': user.uid,
        'patientName': patientName,
        'patientPhone': patientPhone,
        'caregiverUid': caregiverUid,
        'caregiverPhone': caregiverPhone,
        'emergencyContactPhone': emergencyPhone,
        'emergencyContactName': emergencyData?['name'] ?? 'Emergency Contact',
        // Store location only if actually obtained
        'latitude': latitude,
        'longitude': longitude,
        'locationAccuracy': locationData['accuracy'],
        'locationObtained': locationObtained,
        'geoPoint': (latitude != null && longitude != null)
            ? GeoPoint(latitude, longitude)
            : null, // Add GeoPoint for Firestore geoqueries
        'mapUrl': locationData['mapUrl'],
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'pending',
        'acknowledgedBy': null,
        'acknowledgedAt': null,
        'resolvedAt': null,
        'error': locationObtained ? null : locationData['error'],
      });

      // Send SMS to caregiver and emergency contact
      await _sendSosSmsList(
        context: context,
        patientName: patientName,
        caregiverPhone: caregiverPhone,
        emergencyPhone: emergencyPhone,
        latitude: latitude,
        longitude: longitude,
        locationObtained: locationObtained,
      );

      // Send notifications (will be triggered by Cloud Function)
      await _notifyCaregiver(caregiverUid, patientName, locationObtained);

      return alertRef.id;
    } catch (e) {
      debugPrint('Error triggering SOS alert: $e');
      rethrow;
    }
  }

  /// Sanitize phone number to international format digits only (e.g. 919876543210)
  /// Sanitize phone to E.164 digits only (no +, spaces, dashes)
  String _sanitizePhone(String phone) {
    String digits = phone.replaceAll(RegExp(r'[\s\-\(\)\+]'), '');
    if (digits.length == 10) digits = '91$digits';
    return digits;
  }

  /// Check if WhatsApp is installed and can handle a wa.me link
  Future<bool> _canUseWhatsApp(String sanitizedPhone) async {
    try {
      final encoded = Uri.encodeComponent('test');
      final uri = Uri.parse('https://wa.me/$sanitizedPhone?text=$encoded');
      return await canLaunchUrl(uri);
    } catch (_) {
      return false;
    }
  }

  /// Launch WhatsApp with pre-filled message, returns true if launched
  Future<bool> _sendWhatsApp(String sanitizedPhone, String message) async {
    try {
      final encoded = Uri.encodeComponent(message);
      final uri = Uri.parse('https://wa.me/$sanitizedPhone?text=$encoded');
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      debugPrint('WhatsApp launch error: $e');
      return false;
    }
  }

  /// Launch SMS app with pre-filled message
  Future<bool> _sendSms(String sanitizedPhone, String message) async {
    try {
      final uri = Uri(
        scheme: 'sms',
        path: '+$sanitizedPhone',
        queryParameters: {'body': message},
      );
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      debugPrint('SMS launch error: $e');
      return false;
    }
  }

  /// Send SOS to ONE contact — shows an elderly-friendly bottom sheet
  /// letting the patient pick WhatsApp or SMS. If one app is unavailable
  /// it is greyed out with a clear explanation. Both buttons are large.
  Future<void> _sendToContact({
    required BuildContext context,
    required String label,     // "Caregiver" / "Emergency Contact"
    required String phone,
    required String message,
  }) async {
    final sanitized = _sanitizePhone(phone);
    if (sanitized.isEmpty) return;

    final whatsappOk = await _canUseWhatsApp(sanitized);

    if (!context.mounted) return;

    // Use the SosDialogHelper to display the contact selection dialog
    await SosDialogHelper.showSosContactDialog(
      context: context,
      label: label,
      phone: phone,
      whatsappAvailable: whatsappOk,
      onWhatsAppPressed: () async {
        await _sendWhatsApp(sanitized, message);
      },
      onSmsPressed: () async {
        final sent = await _sendSms(sanitized, message);
        if (!sent) {
          debugPrint('SMS also failed for $sanitized');
        }
      },
    );
  }

  /// Entry point — shows a dialog for EACH contact in sequence
  Future<void> _sendSosSmsList({
    required BuildContext context,
    required String patientName,
    required String caregiverPhone,
    required String emergencyPhone,
    required double? latitude,
    required double? longitude,
    required bool locationObtained,
  }) async {
    final locationInfo = (locationObtained && latitude != null && longitude != null)
        ? '\n📍 Location: https://maps.google.com/?q=$latitude,$longitude'
        : '\n⚠️ Location unavailable';

    final message =
        '🚨 EMERGENCY: $patientName needs immediate help!$locationInfo\n'
        'Please call or go to them now.';

    if (caregiverPhone.isNotEmpty && context.mounted) {
      await _sendToContact(
        context: context,
        label: 'Caregiver',
        phone: caregiverPhone,
        message: message,
      );
    }

    // Small gap so OS finishes the first app launch
    await Future.delayed(const Duration(milliseconds: 600));

    if (emergencyPhone.isNotEmpty &&
        emergencyPhone != caregiverPhone &&
        context.mounted) {
      await _sendToContact(
        context: context,
        label: 'Emergency Contact',
        phone: emergencyPhone,
        message: message,
      );
    }
  }

  /// Send notification to caregiver
  Future<void> _notifyCaregiver(
    String caregiverUid,
    String patientName,
    bool locationObtained,
  ) async {
    try {
      await _firestore.collection('notifications').add({
        'recipientUid': caregiverUid,
        'type': 'sos_alert',
        'title': '🚨 EMERGENCY ALERT',
        'message': 'Patient $patientName is requesting immediate help!',
        'data': {
          'type': 'sos_alert',
          'patientName': patientName,
          'priority': 'critical',
          'locationAvailable': locationObtained,
        },
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error sending caregiver notification: $e');
    }
  }

  /// Get active SOS alerts for caregiver
  Stream<List<Map<String, dynamic>>> getActiveSosAlerts() {
    final user = _auth.currentUser;
    if (user == null) return Stream.value([]);

    return _firestore
        .collection('sos_alerts')
        .where('caregiverUid', isEqualTo: user.uid)
        .where('status', isEqualTo: 'pending')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            final data = doc.data();
            data['id'] = doc.id;
            return data;
          }).toList();
        });
  }

  /// Get all SOS alerts for caregiver
  Stream<List<Map<String, dynamic>>> getAllSosAlerts({int limit = 50}) {
    final user = _auth.currentUser;
    if (user == null) return Stream.value([]);

    return _firestore
        .collection('sos_alerts')
        .where('caregiverUid', isEqualTo: user.uid)
        .orderBy('timestamp', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            final data = doc.data();
            data['id'] = doc.id;
            return data;
          }).toList();
        });
  }

  /// Get patient's own SOS alerts
  Stream<List<Map<String, dynamic>>> getPatientSosAlerts() {
    final user = _auth.currentUser;
    if (user == null) return Stream.value([]);

    return _firestore
        .collection('sos_alerts')
        .where('patientUid', isEqualTo: user.uid)
        .orderBy('timestamp', descending: true)
        .limit(10)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            final data = doc.data();
            data['id'] = doc.id;
            return data;
          }).toList();
        });
  }

  /// Acknowledge SOS alert (caregiver)
  Future<void> acknowledgeSosAlert(String alertId) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');

      await _firestore.collection('sos_alerts').doc(alertId).update({
        'status': 'acknowledged',
        'acknowledgedBy': user.uid,
        'acknowledgedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error acknowledging SOS alert: $e');
      rethrow;
    }
  }

  /// Resolve SOS alert (caregiver)
  Future<void> resolveSosAlert(String alertId) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');

      await _firestore.collection('sos_alerts').doc(alertId).update({
        'status': 'resolved',
        'acknowledgedBy': user.uid,
        'resolvedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error resolving SOS alert: $e');
      rethrow;
    }
  }

  /// Call patient (caregiver feature)
  Future<void> callPatient(String phoneNumber) async {
    try {
      final Uri uri = Uri(scheme: 'tel', path: phoneNumber);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      }
    } catch (e) {
      debugPrint('Error calling patient: $e');
    }
  }

  /// Cancel ongoing SOS (patient can cancel if not acknowledged)
  Future<void> cancelSosAlert(String alertId) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');

      final alertDoc = await _firestore.collection('sos_alerts').doc(alertId).get();
      if (!alertDoc.exists) {
        throw Exception('Alert not found');
      }

      final alertData = alertDoc.data()!;
      if (alertData['patientUid'] != user.uid) {
        throw Exception('Unauthorized');
      }

      final currentStatus = alertData['status'] as String?;
      if (currentStatus != 'pending') {
        throw Exception('Cannot cancel alert with status: $currentStatus');
      }

      await _firestore.collection('sos_alerts').doc(alertId).update({
        'status': 'cancelled',
        'cancelledAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error cancelling SOS alert: $e');
      rethrow;
    }
  }

  /// Get SOS alert details
  Future<Map<String, dynamic>?> getSosAlertDetails(String alertId) async {
    try {
      final doc = await _firestore.collection('sos_alerts').doc(alertId).get();
      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }
      return null;
    } catch (e) {
      debugPrint('Error getting SOS alert details: $e');
      return null;
    }
  }

  /// Listen to specific SOS alert for real-time updates
  Stream<Map<String, dynamic>?> watchSosAlert(String alertId) {
    return _firestore
        .collection('sos_alerts')
        .doc(alertId)
        .snapshots()
        .map((doc) {
          if (doc.exists) {
            final data = doc.data() as Map<String, dynamic>;
            data['id'] = doc.id;
            return data;
          }
          return null;
        });
  }

  /// Get location update stream (real-time)
  /// Can be used to monitor patient's live location during SOS
  Stream<Position> getLocationUpdates() {
    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 10, // Update every 10 meters
        timeLimit: Duration(seconds: 5),
      ),
    );
  }

  /// Build Google Maps URL for alert location
  String getAlertLocationUrl(
      {required double latitude, required double longitude}) {
    return 'https://maps.google.com/?q=$latitude,$longitude';
  }

  /// Request background location permission (for continuous monitoring)
  Future<bool> requestBackgroundLocationPermission() async {
    final permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      final result = await Geolocator.requestPermission();
      return result == LocationPermission.always;
    }

    if (permission == LocationPermission.deniedForever) {
      await Geolocator.openAppSettings();
      return false;
    }

    return permission == LocationPermission.always;
  }
}