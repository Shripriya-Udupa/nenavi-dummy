import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  static final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  factory NotificationService() {
    return _instance;
  }

  NotificationService._internal();

  /// Initialize notification services
  Future<void> initialize() async {
    if (_initialized) return;

    // 1. Request FCM permissions
    await _fcm.requestPermission(
  alert: true,
  announcement: true,
  badge: true,
  criticalAlert: false,
  provisional: false,
  sound: true,
);

    // 2. Get and store device token
    final token = await _fcm.getToken();
    if (token != null) {
      await _storeDeviceToken(token);
    }

    // 3. Listen for token refresh
    _fcm.onTokenRefresh.listen(_storeDeviceToken);

    // 4. Initialize local notifications
    await _initializeLocalNotifications();

    // 5. Handle messages when app is in foreground
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // 6. Handle messages when app is terminated or backgrounded
    FirebaseMessaging.onMessageOpenedApp.listen(_handleBackgroundMessage);

    // 7. Check for messages when app starts from terminated state
    final initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      _handleBackgroundMessage(initialMessage);
    }

    _initialized = true;
  }

  /// Initialize local notifications
  Future<void> _initializeLocalNotifications() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _handleNotificationTap,
    );

    // Handle notification tap when app is launched from terminated state
    _localNotifications.getNotificationAppLaunchDetails().then((details) {
      if (details?.didNotificationLaunchApp ?? false) {
        _handleNotificationTap(details!.notificationResponse!);
      }
    });
  }

  /// Store device token in Firestore
  Future<void> _storeDeviceToken(String token) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .update({
            'deviceTokens.${token.hashCode}': {
              'token': token,
              'platform': identical(0, -0.0) ? 'ios' : 'android',
              'storedAt': FieldValue.serverTimestamp(),
            }
          })
          .catchError((e) {
        // If user doc doesn't exist yet, ignore
        debugPrint('Device token storage warning: $e');
      });
    } catch (e) {
      debugPrint('Error storing device token: $e');
    }
  }

  /// Handle message when app is in foreground
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    debugPrint('Foreground message received: ${message.messageId}');

    final data = message.data;
    final title = message.notification?.title ?? 'Nenavi';
    final body = message.notification?.body ?? '';

    // Show local notification
    await _showLocalNotification(
      title: title,
      body: body,
      payload: jsonEncode(data),
    );

    // Store in notifications collection
    await _storeNotification(
      type: data['type'] ?? 'general',
      title: title,
      message: body,
      data: data,
    );
  }

  /// Handle message when app is backgrounded/terminated
  void _handleBackgroundMessage(RemoteMessage message) {
    debugPrint('Background message received: ${message.messageId}');
    // Navigation will be handled by onMessageOpenedApp listener
  }

  /// Handle notification tap
  void _handleNotificationTap(NotificationResponse response) {
  final payload = response.payload;

  if (payload == null) return;

  try {
    final data = jsonDecode(payload) as Map<String, dynamic>;
    _navigateToNotificationTarget(data);
  } catch (e) {
    debugPrint('Error parsing notification payload: $e');
  }
}

  /// Navigate based on notification type
  void _navigateToNotificationTarget(Map<String, dynamic> data) {
    final type = data['type'] as String?;
    
    switch (type) {
      case 'test_reminder':
        // Navigate to assessment screen
        // This will be handled by the calling screen
        break;
      case 'score_update':
        // Navigate to patient history
        break;
      case 'sos_alert':
        // Navigate to SOS alert details
        break;
      default:
        // Navigate to notifications center
        break;
    }
  }

  /// Show local notification
  Future<void> _showLocalNotification({
    required String title,
    required String body,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'nenavi_notifications',
      'Nenavi Notifications',
      channelDescription: 'Notifications for test reminders and alerts',
      importance: Importance.high,
      priority: Priority.high,
      enableVibration: true,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('notification_sound'),
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotifications.show(
      title.hashCode,
      title,
      body,
      notificationDetails,
      payload: payload,
    );
  }

  /// Store notification in Firestore
  Future<void> _storeNotification({
    required String type,
    required String title,
    required String message,
    required Map<String, dynamic> data,
  }) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      await FirebaseFirestore.instance.collection('notifications').add({
        'recipientUid': user.uid,
        'type': type,
        'title': title,
        'message': message,
        'data': data,
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(days: 30))),
      });
    } catch (e) {
      debugPrint('Error storing notification: $e');
    }
  }

  /// Send test reminder notification
  Future<void> sendTestReminder({
    required String patientUid,
    required String patientName,
  }) async {
    try {
      // This is called from Cloud Function
      // but can be used for testing
      await FirebaseFirestore.instance.collection('notifications').add({
        'recipientUid': patientUid,
        'type': 'test_reminder',
        'title': 'Time for Your Assessment',
        'message': 'It\'s been 30 days since your last cognitive assessment. '
            'Please take the test when convenient.',
        'data': {
          'type': 'test_reminder',
          'patientName': patientName,
        },
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error sending test reminder: $e');
    }
  }

  /// Send caregiver notification about patient test completion
  Future<void> sendScoreUpdateNotification({
    required String caregiverUid,
    required String patientName,
    required int score,
    required String date,
  }) async {
    try {
      await FirebaseFirestore.instance.collection('notifications').add({
        'recipientUid': caregiverUid,
        'type': 'score_update',
        'title': 'Assessment Completed',
        'message': '$patientName completed cognitive assessment with score $score',
        'data': {
          'type': 'score_update',
          'patientName': patientName,
          'score': score,
          'date': date,
        },
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error sending score update notification: $e');
    }
  }

  /// Send SOS alert notification
  Future<void> sendSosNotification({
    required String caregiverUid,
    required String patientName,
  }) async {
    try {
      await FirebaseFirestore.instance.collection('notifications').add({
        'recipientUid': caregiverUid,
        'type': 'sos_alert',
        'title': 'EMERGENCY ALERT',
        'message': 'Patient $patientName needs immediate help!',
        'data': {
          'type': 'sos_alert',
          'patientName': patientName,
          'priority': 'critical',
        },
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('Error sending SOS notification: $e');
    }
  }

  /// Get unread notification count
  Stream<int> getUnreadNotificationCount() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return Stream.value(0);

    return FirebaseFirestore.instance
        .collection('notifications')
        .where('recipientUid', isEqualTo: user.uid)
        .where('read', isEqualTo: false)
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  /// Get notifications for user
  Stream<List<Map<String, dynamic>>> getNotifications({int limit = 50}) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return Stream.value([]);

    return FirebaseFirestore.instance
        .collection('notifications')
        .where('recipientUid', isEqualTo: user.uid)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            final data = doc.data();
            data['id'] = doc.id;
            return data;
          }).toList();
        });
  }

  /// Mark notification as read
  Future<void> markAsRead(String notificationId) async {
    try {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(notificationId)
          .update({'read': true});
    } catch (e) {
      debugPrint('Error marking notification as read: $e');
    }
  }

  /// Delete notification
  Future<void> deleteNotification(String notificationId) async {
    try {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(notificationId)
          .delete();
    } catch (e) {
      debugPrint('Error deleting notification: $e');
    }
  }

  /// Clear all notifications
  Future<void> clearAllNotifications() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final batch = FirebaseFirestore.instance.batch();
      final snapshot = await FirebaseFirestore.instance
          .collection('notifications')
          .where('recipientUid', isEqualTo: user.uid)
          .get();

      for (var doc in snapshot.docs) {
        batch.delete(doc.reference);
      }

      await batch.commit();
    } catch (e) {
      debugPrint('Error clearing notifications: $e');
    }
  }
}