import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:workmanager/workmanager.dart';
import 'notification_service.dart';
import 'package:flutter/foundation.dart';

/// Top-level callback required by WorkManager — must NOT be inside a class.
@pragma('vm:entry-point')
void reminderCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == ReminderService._reminderTaskName) {
      await ReminderService._checkAndSendReminders();
    }
    return true;
  });
}

class ReminderService {
  static final ReminderService _instance = ReminderService._internal();
  static final _firestore = FirebaseFirestore.instance;
  static final _auth = FirebaseAuth.instance;
  static final _notificationService = NotificationService();

  static const String _reminderTaskName = 'check_test_reminder';
  static const Duration _reminderInterval = Duration(hours: 1);

  factory ReminderService() {
    return _instance;
  }

  ReminderService._internal();

  /// Initialize reminder service with background tasks
  Future<void> initialize() async {
    try {
      // Initialize WorkManager for background task scheduling
      await Workmanager().initialize(
        reminderCallbackDispatcher,
        isInDebugMode: false,
      );

      // Schedule periodic reminder check (every 1 hour)
      await Workmanager().registerPeriodicTask(
        _reminderTaskName,
        _reminderTaskName,
        frequency: _reminderInterval,
        constraints: Constraints(
          requiresBatteryNotLow: true,
          networkType: NetworkType.connected,
        ),
      );

      debugPrint('Reminder service initialized');
    } catch (e) {
      debugPrint('Error initializing reminder service: $e');
    }
  }



  /// Check all patients and send 30-day reminders
  static Future<void> _checkAndSendReminders() async {
    try {
      final snapshot = await _firestore
          .collection('test_reminders')
          .where('nextReminderDate',
              isLessThanOrEqualTo: DateTime.now())
          .get();

      for (var doc in snapshot.docs) {
        final patientUid = doc.id;
        final patientSnap =
            await _firestore.collection('users').doc(patientUid).get();

        if (patientSnap.exists) {
          final patientData = patientSnap.data() as Map<String, dynamic>;
          final patientName = patientData['name'] as String? ?? 'Patient';

          // Send reminder notification
          await _firestore.collection('notifications').add({
            'recipientUid': patientUid,
            'type': 'test_reminder',
            'title': 'Time for Your Assessment',
            'message':
                'It\'s been 30 days since your last cognitive assessment. '
                'Please take the test when convenient.',
            'data': {
              'type': 'test_reminder',
              'patientName': patientName,
            },
            'read': false,
            'createdAt': FieldValue.serverTimestamp(),
          });

          // Update reminder record
          await _firestore
              .collection('test_reminders')
              .doc(patientUid)
              .update({
            'nextReminderDate': Timestamp.fromDate(DateTime.now().add(const Duration(days: 30))),
            'remindersSent': FieldValue.increment(1),
            'lastReminderSentAt': FieldValue.serverTimestamp(),
          });

          debugPrint('Reminder sent for patient: $patientName');
        }
      }
    } catch (e) {
      debugPrint('Error checking reminders: $e');
    }
  }

  /// Initialize reminder for newly registered patient
  Future<void> initializePatientReminder(String patientUid) async {
    try {
      // Check if reminder record already exists
      final existingReminder =
          await _firestore.collection('test_reminders').doc(patientUid).get();

      if (!existingReminder.exists) {
        // Create new reminder record with 30-day future date
        // This gives patient time to take first test
        await _firestore.collection('test_reminders').doc(patientUid).set({
          'patientUid': patientUid,
          'lastTestDate': null,
          'nextReminderDate': Timestamp.fromDate(DateTime.now().add(const Duration(days: 30))),
          'remindersSent': 0,
          'lastReminderSentAt': null,
        });

        debugPrint('Reminder initialized for patient: $patientUid');
      }
    } catch (e) {
      debugPrint('Error initializing patient reminder: $e');
    }
  }

  /// Update reminder after patient completes test
  Future<void> updateReminderAfterTest(String patientUid) async {
    try {
      final now = DateTime.now();
      final nextReminder = now.add(Duration(days: 30));

      await _firestore.collection('test_reminders').doc(patientUid).update({
        'lastTestDate': Timestamp.fromDate(now),
        'nextReminderDate': Timestamp.fromDate(nextReminder),
        'lastReminderSentAt': null, // Reset so next reminder will be sent
      });

      debugPrint('Reminder updated after test for patient: $patientUid');
    } catch (e) {
      debugPrint('Error updating reminder after test: $e');
    }
  }

  /// Get reminder status for patient
  Future<Map<String, dynamic>?> getReminderStatus(String patientUid) async {
    try {
      final doc =
          await _firestore.collection('test_reminders').doc(patientUid).get();

      if (doc.exists) {
        return doc.data();
      }
      return null;
    } catch (e) {
      debugPrint('Error getting reminder status: $e');
      return null;
    }
  }

  /// Get days until next reminder
  Future<int?> getDaysUntilNextReminder(String patientUid) async {
    try {
      final status = await getReminderStatus(patientUid);
      if (status == null) return null;

      final nextReminderDate = status['nextReminderDate'] as Timestamp?;
      if (nextReminderDate == null) return null;

      final difference = nextReminderDate.toDate().difference(DateTime.now());
      return difference.inDays;
    } catch (e) {
      debugPrint('Error calculating days until reminder: $e');
      return null;
    }
  }

  /// Check if patient is due for reminder
  Future<bool> isPatientDueForReminder(String patientUid) async {
    try {
      final status = await getReminderStatus(patientUid);
      if (status == null) return false;

      final nextReminderDate = status['nextReminderDate'] as Timestamp?;
      if (nextReminderDate == null) return false;

      return nextReminderDate.toDate().isBefore(DateTime.now());
    } catch (e) {
      debugPrint('Error checking if patient is due: $e');
      return false;
    }
  }

  /// Send immediate reminder (for testing or manual trigger)
  Future<void> sendImmediateReminder(String patientUid) async {
    try {
      final patientSnap =
          await _firestore.collection('users').doc(patientUid).get();

      if (!patientSnap.exists) {
        throw Exception('Patient not found');
      }

      final patientData = patientSnap.data() as Map<String, dynamic>;
      final patientName = patientData['name'] as String? ?? 'Patient';

      // Send notification
      await _firestore.collection('notifications').add({
        'recipientUid': patientUid,
        'type': 'test_reminder',
        'title': 'Cognitive Assessment Reminder',
        'message':
            'It\'s time for your cognitive assessment. Please take the test.',
        'data': {
          'type': 'test_reminder',
          'patientName': patientName,
          'manual': true,
        },
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      debugPrint('Immediate reminder sent to: $patientName');
    } catch (e) {
      debugPrint('Error sending immediate reminder: $e');
      rethrow;
    }
  }

  /// Get all patients due for reminders (admin/system use)
  Future<List<String>> getPatientsDueForReminders() async {
    try {
      final snapshot = await _firestore
          .collection('test_reminders')
          .where('nextReminderDate',
              isLessThanOrEqualTo: DateTime.now())
          .get();

      return snapshot.docs.map((doc) => doc.id).toList();
    } catch (e) {
      debugPrint('Error getting patients due for reminders: $e');
      return [];
    }
  }

  /// Get reminder statistics
  Future<Map<String, dynamic>> getReminderStats() async {
    try {
      final totalSnapshot =
          await _firestore.collection('test_reminders').count().get();

      final dueSnapshot = await _firestore
          .collection('test_reminders')
          .where('nextReminderDate',
              isLessThanOrEqualTo: DateTime.now())
          .count()
          .get();

      return {
        'totalPatients': totalSnapshot.count,
        'patientsDue': dueSnapshot.count,
        'lastCheck': DateTime.now(),
      };
    } catch (e) {
      debugPrint('Error getting reminder stats: $e');
      return {};
    }
  }

  /// Cleanup old reminder records (optional maintenance)
  Future<void> cleanupOldReminders({int daysOld = 365}) async {
    try {
      final cutoffDate = DateTime.now().subtract(Duration(days: daysOld));

      final snapshot = await _firestore
          .collection('test_reminders')
          .where('lastTestDate', isLessThan: cutoffDate)
          .get();

      for (var doc in snapshot.docs) {
        // Optionally archive instead of delete
        // await doc.reference.delete();
      }

      debugPrint('Cleanup completed for reminders older than $daysOld days');
    } catch (e) {
      debugPrint('Error cleaning up old reminders: $e');
    }
  }

  /// Cancel periodic task (when app is uninstalled or user opts out)
  Future<void> cancelReminders() async {
    try {
      await Workmanager().cancelByTag(_reminderTaskName);
      debugPrint('Reminders cancelled');
    } catch (e) {
      debugPrint('Error cancelling reminders: $e');
    }
  }
}