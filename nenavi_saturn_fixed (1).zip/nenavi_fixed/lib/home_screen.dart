import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'screens/daily_assessment/seed_phrase_screen.dart';
import 'screens/daily_assessment/j_word_task_screen.dart';
import 'screens/daily_assessment/fruit_task_screen.dart';
import 'screens/daily_assessment/attention_task_screen.dart';
import 'screens/daily_assessment/word_recall_encoding_screen.dart';
import 'screens/daily_assessment/orientation_screen.dart';
import 'screens/daily_assessment/delayed_word_recall_screen.dart';
import 'screens/daily_assessment/calculation_screen.dart';
import 'screens/daily_assessment/incidental_memory_screen.dart';
import 'screens/daily_assessment/trails_task_screen.dart';
import 'screens/daily_assessment/stroop_task_screen.dart';
import 'screens/daily_assessment/visualization_task_screen.dart';
import 'screens/daily_assessment/number_recall_screen.dart';
import 'screens/daily_assessment/j_word_recall_screen.dart';
import 'package:nenavi/screens/patient_history_screen.dart';
import 'services/database_helper.dart';
import 'main.dart';
import 'localization.dart';
import 'widgets/language_selector.dart';
import 'widgets/sos_button.dart';
import 'dart:async';
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int? _lastScore;
  String? _lastDate;
  bool _isAssessing = false;
  String? _userName;

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadUserName();
  }

  Future<void> _loadUserName() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    // Prefer displayName from FirebaseAuth first (fast)
    if (user.displayName != null && user.displayName!.trim().isNotEmpty) {
      if (mounted) setState(() => _userName = user.displayName!.trim());
      return;
    }
    // Fall back to Firestore users/{uid}.name
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final name = doc.data()?['name'] as String?;
      if (mounted && name != null && name.trim().isNotEmpty) {
        setState(() => _userName = name.trim());
      }
    } catch (_) {}
  }

  Future<void> _loadData() async {
    final user = FirebaseAuth.instance.currentUser;
    final latest = await DatabaseHelper().getLatestScore(patientUid: user?.uid);
    if (!mounted) return;
    if (latest != null) {
      setState(() {
        _lastScore = latest['composite_score'] as int?;
        _lastDate = latest['date'] as String?;
      });
    }
  }

  Future<void> _startAssessment() async {
    if (_isAssessing) return;
    setState(() => _isAssessing = true);
    final lang = globalLanguage.value;
    final startTime = DateTime.now();
    final endTime = startTime.add(const Duration(minutes: 15));

    try {
      // ── Step 1: Seed phrase (I am a good person) ──────────────────────────
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (ctx) => SeedPhraseScreen(
            language: lang,
            endTime: endTime,
            onComplete: () => Navigator.pop(ctx),
          ),
        ),
      );
      if (!mounted) { setState(() => _isAssessing = false); return; }

      // ── Step 2: J-word pick ────────────────────────────────────────────────
      final jWordResult = await Navigator.push<List<dynamic>>(
        context,
        MaterialPageRoute(
          builder: (ctx) => JWordTaskScreen(
            language: lang,
            endTime: endTime,
            onComplete: (score, word) => Navigator.pop(ctx, [score, word]),
          ),
        ),
      );
      if (!mounted || jWordResult == null) { setState(() => _isAssessing = false); return; }
      final jWordScore = jWordResult[0] as int;
      final chosenJWord = jWordResult[1] as String;

      // ── Step 2b: Fruit selection (attention task 2) ────────────────────────
      final fruitScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => FruitTaskScreen(
            language: lang,
            endTime: endTime,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || fruitScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 3: Attention task (number 1239) ───────────────────────────────
      final attResult = await Navigator.push<List<dynamic>>(
        context,
        MaterialPageRoute(
          builder: (ctx) => AttentionTaskScreen(
            language: lang,
            endTime: endTime,
            onComplete: (score, seed, enteredNumber) =>
                Navigator.pop(ctx, [score, seed, enteredNumber]),
          ),
        ),
      );
      if (!mounted || attResult == null) { setState(() => _isAssessing = false); return; }
      final attScore = attResult[0] as int;
      final seedPhrase = attResult[1] as String;
      final enteredNumber = attResult[2] as String;

      // ── Step 4: Word recall encoding (remember 5 words) ───────────────────
      final encodedWords = await Navigator.push<List<String>>(
        context,
        MaterialPageRoute(
          builder: (ctx) => WordRecallEncodingScreen(
            language: lang,
            endTime: endTime,
            onComplete: (w) => Navigator.pop(ctx, w),
          ),
        ),
      );
      if (!mounted || encodedWords == null) { setState(() => _isAssessing = false); return; }

      // ── Step 5: Incidental memory — remember the sentence ─────────────────
      final incidentalScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => IncidentalMemoryScreen(
            language: lang,
            endTime: endTime,
            seedPhrase: seedPhrase,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || incidentalScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 6: Number recall (enter 1239 again) ───────────────────────────
      final numberRecallScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => NumberRecallScreen(
            language: lang,
            endTime: endTime,
            targetNumber: enteredNumber.isNotEmpty ? enteredNumber : '1239',
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || numberRecallScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 7: J-word recall ──────────────────────────────────────────────
      final jWordRecallScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => JWordRecallScreen(
            language: lang,
            endTime: endTime,
            correctWord: chosenJWord,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || jWordRecallScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 8: Orientation (month, year, day, state) ─────────────────────
      final orientationScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => OrientationScreen(
            language: lang,
            endTime: endTime,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || orientationScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 9: Delayed word recall (right after orientation/state) ────────
      final delayedScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => DelayedWordRecallScreen(
            language: lang,
            endTime: endTime,
            originalWords: encodedWords,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || delayedScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 10: Calculation ────────────────────────────────────────────────
      final calcScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => CalculationScreen(
            language: lang,
            endTime: endTime,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || calcScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 11: Trails ────────────────────────────────────────────────────
      final trailsScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => TrailsTaskScreen(
            language: lang,
            endTime: endTime,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || trailsScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 12: Stroop ────────────────────────────────────────────────────
      final stroopScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => StroopTaskScreen(
            language: lang,
            endTime: endTime,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || stroopScore == null) { setState(() => _isAssessing = false); return; }

      // ── Step 13: Visuospatial ──────────────────────────────────────────────
      final visuospatialScore = await Navigator.push<int>(
        context,
        MaterialPageRoute(
          builder: (ctx) => VisualizationTaskScreen(
            language: lang,
            endTime: endTime,
            onComplete: (s) => Navigator.pop(ctx, s),
          ),
        ),
      );
      if (!mounted || visuospatialScore == null) { setState(() => _isAssessing = false); return; }

      // ── Scoring (SATURN 0-30 scale) ───────────────────────────────────────
      // SATURN validated scoring structure:
      // - J-word pick (attention):      0-2 pts (2 if correct first attempt)
      // - Fruit selection (attention):  0-2 pts (2 if perfect first attempt)
      // - Number entry (attention):     0-2 pts (2 if correct first attempt)
      // - Incidental phrase recall:     0-1 pt
      // - Number recall (delayed):      0-1 pt
      // - J-word recall (delayed):      0-1 pt
      // - Orientation:                  0-4 pts (1 pt each: month, year, day, state)
      // - Calculation:                  0-3 pts (Q1=1 pt, Q2=2 pts)
      // - Delayed word recall:          0-5 pts (1 pt per word, 5 words)
      // - Trails:                       0-2 pts (1 pt each: A and B)
      // - Stroop:                       0-3 pts (errors: 0→3, 1→2, 2→1, 3+→0)
      // - Visuospatial:                 0-4 pts (1 pt per puzzle, 4 puzzles)
      // Total: 0-30 points (validated SATURN scale)
      
      final total =
          jWordScore +
          fruitScore +
          attScore +
          incidentalScore +
          numberRecallScore +
          jWordRecallScore +
          orientationScore +
          calcScore +
          delayedScore +
          trailsScore +
          stroopScore +
          visuospatialScore;
      
      // SATURN composite score (direct 0-30 point scale, not percentage)
      final composite = total;
      final today = DateTime.now().toIso8601String().split('T')[0];
      final endedAt = DateTime.now();
      final durationSeconds = endedAt.difference(startTime).inSeconds;
      final domainMap = {
        'j_word': jWordScore,
        'fruit': fruitScore,
        'attention': attScore,
        'incidental_memory': incidentalScore,
        'number_recall': numberRecallScore,
        'j_word_recall': jWordRecallScore,
        'orientation': orientationScore,
        'calculation': calcScore,
        'delayed_recall': delayedScore,
        'trails': trailsScore,
        'stroop': stroopScore,
        'visuospatial': visuospatialScore,
      };
      final user = FirebaseAuth.instance.currentUser;

      await DatabaseHelper().insertScore({
        'date': today,
        'composite_score': composite,
        'domain_scores': jsonEncode(domainMap),
        'difficulty': 'Basic',
        'patient_uid': user?.uid,
        'duration_seconds': durationSeconds,
      });

      if (user != null) {
        try {
          await FirebaseFirestore.instance
              .collection('scores')
              .doc('${user.uid}_$today')
              .set({
                'patientUid': user.uid,
                'date': today,
                'compositeScore': composite,
                'domainScores': domainMap,
                'difficulty': 'Basic',
                'durationSeconds': durationSeconds,
                'timestamp': FieldValue.serverTimestamp(),
              });
        } catch (e) {
          debugPrint('Firestore save error: $e');
        }
      }

      if (!mounted) return;
      await _loadData();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Assessment complete! Score: $composite / 30'),
          backgroundColor: NenaviTheme.secondary,
        ),
      );
    } catch (e, s) {
      debugPrint('Error: $e\n$s');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red.shade800,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isAssessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return ValueListenableBuilder<String>(
      valueListenable: globalLanguage,
      builder: (context, lang, child) {
        return Scaffold(
          backgroundColor: NenaviTheme.background,
          appBar: AppBar(
            title: Text(Localization.get('dashboard_title', lang)),
            actions: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8.0),
                child: LanguageSelector(),
              ),
              IconButton(
                icon: const Icon(Icons.logout),
                tooltip: Localization.get('sign_out', lang),
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                  if (!context.mounted) return;
                  Navigator.pushReplacementNamed(context, '/login');
                },
              ),
            ],
          ),
          body: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                // Compact mode when screen height is tight (e.g. small phones)
                final compact = constraints.maxHeight < 650;
                return Column(
                  children: [
                    // ── Scrollable content ──────────────────────────────────
                    Expanded(
                      child: SingleChildScrollView(
                        padding: EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: compact ? 16 : 24,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // ── Greeting and Score side by side ─────────────────
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 6,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        Localization.get('good_day', lang),
                                        style: NenaviTheme.heading(color: NenaviTheme.accent),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        _userName ?? user?.email?.split('@').first ?? 'User',
                                        style: NenaviTheme.body(
                                          color: NenaviTheme.secondary,
                                        ).copyWith(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      if (user?.email != null && user!.email!.isNotEmpty) ...[
                                        const SizedBox(height: 2),
                                        Text(
                                          user.email!,
                                          style: NenaviTheme.body(
                                            color: NenaviTheme.secondary,
                                          ).copyWith(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w400,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 12),
                                if (_lastScore != null)
                                  Expanded(
                                    flex: 5,
                                    child: _ScoreCard(
                                      score: _lastScore!,
                                      date: _lastDate ?? '',
                                      lang: lang,
                                    ),
                                  ),
                              ],
                            ),
                            SizedBox(height: compact ? 12 : 20),

                            // ── Start assessment ──────────────────────────────────
                            _BigActionCard(
                              icon: Icons.assignment_outlined,
                              title: Localization.get('start_test', lang),
                              subtitle: Localization.get('test_subtitle', lang),
                              buttonLabel: _isAssessing
                                  ? Localization.get('test_in_progress', lang)
                                  : Localization.get('start_test', lang),
                              onTap: _isAssessing ? null : _startAssessment,
                              loading: _isAssessing,
                              lang: lang,
                            ),
                            SizedBox(height: compact ? 10 : 14),

                            // ── View history ──────────────────────────────────────
                            _BigActionCard(
                              icon: Icons.bar_chart_rounded,
                              title: Localization.get('score_history', lang),
                              subtitle: Localization.get('history_subtitle', lang),
                              buttonLabel: Localization.get('view_scores', lang),
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const PatientHistoryScreen(),
                                ),
                              ),
                              lang: lang,
                            ),
                          ],
                        ),
                      ),
                    ),

                    // ── Emergency SOS — always at bottom ─────────────────
                    // ── Emergency SOS — always at bottom ─────────────────
                  Padding(
                    padding: EdgeInsets.fromLTRB(
                      24,
                      compact ? 4 : 6,
                      24,
                      compact ? 4 : 6,
                    ),
                    child: SosButton(
                      compact: compact,
                      onSuccess: () {
                        debugPrint('SOS alert sent successfully');
                      },
                      onError: (error) {
                        debugPrint('SOS error: $error');
                      },
                    ),
                  ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }
}

class _ScoreCard extends StatelessWidget {
  final int score;
  final String date;
  final String lang;

  const _ScoreCard({
    required this.score,
    required this.date,
    required this.lang,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 110,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: scoreColor(score),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: scoreTextColor(score).withValues(alpha: 0.22),
          width: 1.2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            Localization.get('last_score', lang),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: NenaviTheme.label(
              color: scoreTextColor(score),
            ).copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '$score / 30',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: NenaviTheme.subheading(
              color: scoreTextColor(score),
            ).copyWith(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            date,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: NenaviTheme.small(
              color: scoreTextColor(score),
            ).copyWith(
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _BigActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String buttonLabel;
  final VoidCallback? onTap;
  final bool loading;
  final String lang;
  const _BigActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.buttonLabel,
    this.onTap,
    this.loading = false,
    required this.lang,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: NenaviTheme.cardBg,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: NenaviTheme.accent.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: NenaviTheme.primary.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: NenaviTheme.primary, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: NenaviTheme.subheading(color: NenaviTheme.accent),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: NenaviTheme.body(
                        color: NenaviTheme.secondary,
                      ).copyWith(fontSize: 15),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          loading
              ? const Center(child: CircularProgressIndicator())
              : ElevatedButton(onPressed: onTap, child: Text(buttonLabel)),
        ],
      ),
    );
  }
}