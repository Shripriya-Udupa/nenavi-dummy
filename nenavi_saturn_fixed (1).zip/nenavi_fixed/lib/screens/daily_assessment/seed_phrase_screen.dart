import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Step 1 of the assessment — patient reads/listens to the seed phrase
/// "I AM A GOOD PERSON". No scoring; just acknowledgement via Next.
/// FIRST, shows font size calibration screen.
class SeedPhraseScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final VoidCallback onComplete;

  const SeedPhraseScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  State<SeedPhraseScreen> createState() => _SeedPhraseScreenState();
}

class _SeedPhraseScreenState extends State<SeedPhraseScreen> {
  bool _showingFontSizeCalibration = true;
  double _adjustedFontSize = 28.0; // Default font size for seed phrase

  // ── Localisation ──────────────────────────────────────────────────────────
  static const _strings = {
    'en': {
      'fontSizeTitle': 'Adjust Text Size',
      'fontSizeHelp': 'Use the slider below to set the text size that\'s comfortable for you',
      'fontSizeInstruction': 'I am a good person',
      'fontSizeContinue': 'Continue',
    },
    'kn': {
      'fontSizeTitle': 'ಪಠ್ಯ ಗಾತ್ರ ಸರಿಹೊಂದಿಸಿ',
      'fontSizeHelp': 'ನಿಮಗೆ ಆರಾಮದಾಯಕವಾದ ಪಠ್ಯ ಗಾತ್ರವನ್ನು ಹೊಂದಿಸಲು ಕೆಳಗಿನ ಸ್ಲೈಡರ್ ಅನ್ನು ಬಳಸಿ',
      'fontSizeInstruction': 'ನಾನು ಒಬ್ಬ ಒಳ್ಳೆಯ ವ್ಯಕ್ತಿ.',
      'fontSizeContinue': 'ಮುಂದುವರಿಸಿ',
    },
    'tcy': {
      'fontSizeTitle': 'ಪಠ್ಯದ ಗಾತ್ರೊನು ಸರಿ ಮಲ್ಪುಲೆ',
      'fontSizeHelp': 'ನಿಕ್ಲೆಗ್ ಆರಾಮದಾಯಕವಾದ್ ಉಪ್ಪುನ ಪಠ್ಯದ ಗಾತ್ರೊನು ನಿಗದಿ ಮಲ್ಪರೆ ಕೆಳಕಂಡ ಸ್ಲೈಡರ್ ನ್ ಬಳಕೆ ಮಲ್ಪುಲೆ',
      'fontSizeInstruction': 'ಯಾನ್ ಒರಿ ಎಡ್ಡೆ ವ್ಯಕ್ತಿ',
      'fontSizeContinue': 'ದುಂಬರಿಪು',
    },
  };

  String _t(String key) {
    final lang = widget.language;
    return (_strings[lang] ?? _strings['en']!)[key]!;
  }

  @override
  Widget build(BuildContext context) {
    return _showingFontSizeCalibration
        ? _buildFontSizeCalibration()
        : _buildSeedPhrase(context);
  }

  Widget _buildFontSizeCalibration() {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Adjust Text Size'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (mounted) widget.onComplete();
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              Text(
                _t('fontSizeTitle'),
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                _t('fontSizeHelp'),
                style: const TextStyle(fontSize: 20, color: Color.fromARGB(255, 29, 2, 2)),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              
              // ── Sample text with adjustable font size ──────────────────────────
              Container(
                padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade300, width: 2),
                ),
                child: Text(
                  _t('fontSizeInstruction'),
                  style: TextStyle(
                    fontSize: _adjustedFontSize,
                    fontWeight: FontWeight.bold,
                    height: 1.4,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 32),
              
              // ── Slider ────────────────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  children: [
                    Text(
                      'Font Size: ${_adjustedFontSize.toStringAsFixed(1)}',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Slider(
                      value: _adjustedFontSize,
                      min: 12.0,
                      max: 36.0,
                      divisions: 24,
                      label: _adjustedFontSize.toStringAsFixed(1),
                      onChanged: (newValue) {
                        setState(() {
                          _adjustedFontSize = newValue;
                        });
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              
              // ── Continue button ───────────────────────────────────────────────
              SizedBox(
                height: 56,
                child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _showingFontSizeCalibration = false;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  child: Text(_t('fontSizeContinue')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSeedPhrase(BuildContext context) {
    final data =
        QuestionBank.seedPhrase[widget.language] ?? QuestionBank.seedPhrase['en']!;
    final instruction = data['instruction'] as String;
    final phrase = data['phrase'] as String;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Read Aloud'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (context.mounted) widget.onComplete();
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 16),
              Text(
                instruction,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Center(
                child: PlayAudioButton(
                  textToRead: '$instruction. $phrase',
                  language: widget.language,
                  label: 'Read Aloud',
                ),
              ),
              const SizedBox(height: 40),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Text(
                  phrase,
                  style: TextStyle(
                    fontSize: _adjustedFontSize,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: widget.onComplete,
                child: const Text('Next'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}