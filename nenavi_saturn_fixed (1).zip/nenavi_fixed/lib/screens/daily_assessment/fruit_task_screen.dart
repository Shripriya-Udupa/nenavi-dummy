import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Attention Task 2 — Fruit Selection.
/// Patient selects ALL the fruit words from a mixed list.
/// SATURN scoring: 2 pts if every correct item is selected on first Submit,
/// 0 pts otherwise. No retry allowed.
class FruitTaskScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final Function(int score) onComplete;

  const FruitTaskScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  State<FruitTaskScreen> createState() => _FruitTaskScreenState();
}

class _FruitTaskScreenState extends State<FruitTaskScreen> {
  final Set<String> _selected = {};
  bool _submitted = false;

  late String _instruction;
  late List<String> _options;
  late Set<String> _correct;

  @override
  void initState() {
    super.initState();
    final data = QuestionBank.fruitTask[widget.language] ??
        QuestionBank.fruitTask['en']!;
    _instruction = data['instruction'] as String;
    _options = List<String>.from(data['options'] as List);
    _correct = Set<String>.from(data['correct'] as List);
  }

  @override
  void dispose() {
    TtsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Word Selection'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (mounted) widget.onComplete(0);
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      _instruction,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: PlayAudioButton(
                        textToRead: '$_instruction. ${_options.join(', ')}',
                        language: widget.language,
                        label: 'Read Question',
                      ),
                    ),
                    const SizedBox(height: 24),
                    for (int i = 0; i < _options.length; i += 2)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          children: [
                            _WordButton(
                              word: _options[i],
                              isSelected: _selected.contains(_options[i]),
                              onTap: () => setState(() {
                                if (_selected.contains(_options[i])) {
                                  _selected.remove(_options[i]);
                                } else {
                                  _selected.add(_options[i]);
                                }
                              }),
                            ),
                            const SizedBox(width: 12),
                            if (i + 1 < _options.length)
                              _WordButton(
                                word: _options[i + 1],
                                isSelected: _selected.contains(_options[i + 1]),
                                onTap: () => setState(() {
                                  if (_selected.contains(_options[i + 1])) {
                                    _selected.remove(_options[i + 1]);
                                  } else {
                                    _selected.add(_options[i + 1]);
                                  }
                                }),
                              )
                            else
                              const Expanded(child: SizedBox()),
                          ],
                        ),
                      ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: _selected.isEmpty
                    ? null
                    : () {
                        // SATURN: 2 pts for perfect selection on first attempt
                        final perfectFirstAttempt =
                            !_submitted && _selected.length == _correct.length &&
                            _selected.containsAll(_correct);
                        _submitted = true;
                        widget.onComplete(perfectFirstAttempt ? 2 : 0);
                      },
                child: const Text('Submit'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WordButton extends StatelessWidget {
  final String word;
  final bool isSelected;
  final VoidCallback onTap;

  const _WordButton({
    required this.word,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? Colors.blue.shade400 : Colors.white,
          foregroundColor: isSelected ? Colors.white : Colors.black87,
          elevation: isSelected ? 2 : 1,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: isSelected
                  ? Colors.blue.shade600
                  : Colors.grey.shade300,
            ),
          ),
        ),
        onPressed: onTap,
        child: Text(
          word,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
