import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';
import 'package:nenavi/main.dart';

class WordRecallEncodingScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final Function(List<String> words) onComplete;

  const WordRecallEncodingScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  State<WordRecallEncodingScreen> createState() =>
      _WordRecallEncodingScreenState();
}

class _WordRecallEncodingScreenState extends State<WordRecallEncodingScreen> {
  late List<String> _wordsToRemember;
  late String _instruction;

  @override
  void initState() {
    super.initState();
    final data =
        QuestionBank.wordRecall[widget.language] ??
        QuestionBank.wordRecall['en']!;
    _wordsToRemember = List<String>.from(data['wordsToRemember']);
    _instruction = data['instruction'] as String;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('Word Memory'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (mounted) widget.onComplete(_wordsToRemember);
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ── Header: instruction + audio button ──────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    _instruction,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Center(
                    child: PlayAudioButton(
                      textToRead: '$_instruction. ${_wordsToRemember.join(', ')}',
                      language: widget.language,
                      label: 'Read Words',
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),

            // ── Word cards — scrollable so they never overflow ──────────
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(24, 4, 24, 8),
                itemCount: _wordsToRemember.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final word = _wordsToRemember[i];
                  return Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        vertical: 16, horizontal: 16),
                    decoration: BoxDecoration(
                      color: NenaviTheme.cardBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: NenaviTheme.secondary.withValues(alpha: 0.4)),
                      boxShadow: [
                        BoxShadow(
                          color: NenaviTheme.secondary.withValues(alpha: 0.08),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Text(
                      word,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  );
                },
              ),
            ),

            // ── Button always pinned at bottom ──────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onPressed: () => widget.onComplete(_wordsToRemember),
                child: const Text('I have remembered them'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    TtsService.stop();
    super.dispose();
  }
}
