import 'package:flutter/material.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Delayed J-word recall — patient picks the same word starting with "J"
/// that they selected earlier, from the same list.
class JWordRecallScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final String correctWord; // the word the patient chose in JWordTaskScreen
  final Function(int score) onComplete;

  const JWordRecallScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.correctWord,
    required this.onComplete,
  });

  @override
  State<JWordRecallScreen> createState() => _JWordRecallScreenState();
}

class _JWordRecallScreenState extends State<JWordRecallScreen> {
  String? _selectedWord;

  late String _instruction;
  late List<String> _options;

  @override
  void initState() {
    super.initState();
    _instruction = QuestionBank.jWordRecallInstruction[widget.language] ??
        QuestionBank.jWordRecallInstruction['en']!;
    final data = QuestionBank.jWordTask[widget.language] ??
        QuestionBank.jWordTask['en']!;
    _options = List<String>.from(data['options'] as List);
  }

  @override
  void dispose() {
    TtsService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Word Recall'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                final score = _selectedWord == widget.correctWord ? 1 : 0;
                if (mounted) widget.onComplete(score);
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      _instruction,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        PlayAudioButton(
                          textToRead: _instruction,
                          language: widget.language,
                          label: 'Read Question',
                        ),
                        PlayAudioButton(
                          textToRead: _options.join(', '),
                          language: widget.language,
                          label: 'Read Options',
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    for (int i = 0; i < _options.length; i += 2)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          children: [
                            _WordButton(
                              word: _options[i],
                              isSelected: _selectedWord == _options[i],
                              onTap: () =>
                                  setState(() => _selectedWord = _options[i]),
                            ),
                            const SizedBox(width: 12),
                            if (i + 1 < _options.length)
                              _WordButton(
                                word: _options[i + 1],
                                isSelected: _selectedWord == _options[i + 1],
                                onTap: () => setState(
                                    () => _selectedWord = _options[i + 1]),
                              )
                            else
                              const Expanded(child: SizedBox()),
                          ],
                        ),
                      ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: _selectedWord == null
                    ? null
                    : () {
                        final score =
                            _selectedWord == widget.correctWord ? 1 : 0;
                        widget.onComplete(score);
                      },
                child: const Text('Submit'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WordButton extends StatelessWidget {
  final String word;
  final bool isSelected;
  final VoidCallback onTap;

  const _WordButton({
    required this.word,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              isSelected ? Colors.blue.shade400 : Colors.white,
          foregroundColor: isSelected ? Colors.white : Colors.black87,
          elevation: isSelected ? 2 : 1,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: isSelected
                  ? Colors.blue.shade600
                  : Colors.grey.shade300,
            ),
          ),
        ),
        onPressed: onTap,
        child: Text(
          word,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
