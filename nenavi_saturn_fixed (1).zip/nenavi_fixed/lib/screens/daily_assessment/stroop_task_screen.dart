import 'dart:math';
import 'package:flutter/material.dart';
import 'package:nenavi/widgets/assessment_timer.dart';
import 'package:nenavi/widgets/speakable_text.dart';

// ── Stroop Task Screen ────────────────────────────────────────────────────────
// Presents words written in a colour that may differ from the word itself.
// The patient must choose the INK COLOUR, not read the word.
//
// SATURN scoring (0–3):
//   Items 0-2  : warm-up (hand/book/table) — NOT scored
//   Items 3-14 : 12 classic Stroop items — errors counted
//   0 errors → 3 pts | 1 error → 2 pts | 2 errors → 1 pt | 3+ errors → 0 pts
//   Timer expire: remaining unfinished scored items each count as 1 error.

class StroopTaskScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final Function(int score) onComplete;

  const StroopTaskScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.onComplete,
  });

  @override
  State<StroopTaskScreen> createState() => _StroopTaskScreenState();
}

class _StroopTaskScreenState extends State<StroopTaskScreen> {
  // ── Instruction phase ─────────────────────────────────────────────────────
  bool _showingInstructions = true;

  // ── Items ─────────────────────────────────────────────────────────────────
  static const _baseItems = [
    // warm-up (indices 0-2, NOT scored)
    _StroopItem(wordKey: 'hand',  ink: Colors.blue,  correctKey: 'blue'),
    _StroopItem(wordKey: 'book',  ink: Colors.red,   correctKey: 'red'),
    _StroopItem(wordKey: 'table', ink: Colors.green, correctKey: 'green'),
    // classic Stroop (indices 3-14, scored)
    _StroopItem(wordKey: 'green', ink: Colors.blue,  correctKey: 'blue'),
    _StroopItem(wordKey: 'red',   ink: Colors.green, correctKey: 'green'),
    _StroopItem(wordKey: 'blue',  ink: Colors.red,   correctKey: 'red'),
    _StroopItem(wordKey: 'red',   ink: Colors.blue,  correctKey: 'blue'),
    _StroopItem(wordKey: 'blue',  ink: Colors.green, correctKey: 'green'),
    _StroopItem(wordKey: 'green', ink: Colors.red,   correctKey: 'red'),
    _StroopItem(wordKey: 'red',   ink: Colors.red,   correctKey: 'red'),
    _StroopItem(wordKey: 'blue',  ink: Colors.blue,  correctKey: 'blue'),
    _StroopItem(wordKey: 'red',   ink: Colors.blue,  correctKey: 'blue'),
    _StroopItem(wordKey: 'green', ink: Colors.red,   correctKey: 'red'),
    _StroopItem(wordKey: 'blue',  ink: Colors.green, correctKey: 'green'),
    _StroopItem(wordKey: 'green', ink: Colors.green, correctKey: 'green'),
  ];

  static List<_StroopItem> _shuffleNoBackToBack(List<_StroopItem> items) {
    final list = List<_StroopItem>.from(items)..shuffle();
    const maxPasses = 200;
    int pass = 0;
    bool changed = true;
    while (changed && pass++ < maxPasses) {
      changed = false;
      for (int i = 0; i < list.length - 1; i++) {
        if (list[i].correctKey == list[i + 1].correctKey) {
          for (int j = i + 2; j < list.length; j++) {
            if (list[j].correctKey != list[i].correctKey &&
                (i == 0 || list[i - 1].correctKey != list[j].correctKey) &&
                (j + 1 >= list.length ||
                    list[j + 1].correctKey != list[i + 1].correctKey)) {
              final tmp = list[i + 1];
              list[i + 1] = list[j];
              list[j] = tmp;
              changed = true;
              break;
            }
          }
        }
      }
    }
    return list;
  }

  /// Warm-up items are fixed at the front; only the 12 classic items are shuffled.
  late final List<_StroopItem> _items = [
    ..._baseItems.take(3),
    ..._shuffleNoBackToBack(List<_StroopItem>.from(_baseItems.skip(3))),
  ];

  // ── Localisation ──────────────────────────────────────────────────────────
  static const _strings = {
    'en': {
      'appBarTitle': 'Stroop Task',
      'instruction':
          'NEXT, YOU WILL SEE SOME WORDS.\n'
          'CHOOSE THE COLOR USED TO WRITE EACH WORD.',
      'begin':    'Begin',
      'hand':     'HAND',
      'book':     'BOOK',
      'table':    'TABLE',
      'red':      'RED',
      'green':    'GREEN',
      'blue':     'BLUE',
      'btnRed':   'Red',
      'btnGreen': 'Green',
      'btnBlue':  'Blue',
    },
    'kn': {
      'appBarTitle': 'ಸ್ಟ್ರೂಪ್ ಪರೀಕ್ಷೆ',
      'instruction':
          'ಮುಂದೆ, ನೀವು ಕೆಲವು ಪದಗಳನ್ನು ನೋಡುತ್ತೀರಿ.\n'
          'ಪ್ರತಿ ಪದವನ್ನು ಬರೆಯಲು ಬಳಸುವ ಬಣ್ಣವನ್ನು ಆರಿಸಿ.',
      'begin':    'ಪ್ರಾರಂಭಿಸಿ',
      'hand':     'ಕೈ',
      'book':     'ಪುಸ್ತಕ',
      'table':    'ಮೇಜು',
      'red':      'ಕೆಂಪು',
      'green':    'ಹಸಿರು',
      'blue':     'ನೀಲಿ',
      'btnRed':   'ಕೆಂಪು',
      'btnGreen': 'ಹಸಿರು',
      'btnBlue':  'ನೀಲಿ',
    },
    'tcy': {
      'appBarTitle': 'ಸ್ಟ್ರೂಪ್ ಪರೀಕ್ಷೆ',
      'instruction':
          'ದುಂಬು, ಈರ್ ಕೆಲವ್ ಪದಲೆನ್ ತೂಪರ್.\n'
          'ಪ್ರತಿಯೊಂಜಿ ಪದೊನ್ ಬರೆಯೆರೆ ಉಪಯೋಗ ಮಲ್ಪುನ ಬಣ್ಣ ಆಯ್ಕೆ ಮಲ್ಪುಲೆ.',
      'begin':    'ಸುರು ಮಲ್ಪುಲೆ',
      'hand':     'ಕೈ',
      'book':     'ಪುಸ್ತಕ',
      'table':    'ಮೇಜ್',
      'red':      'ಕೆಂಪ್',
      'green':    'ಪಚ್ಚೆ',
      'blue':     'ನೀಲಿ',
      'btnRed':   'ಕೆಂಪ್',
      'btnGreen': 'ಪಚ್ಚೆ',
      'btnBlue':  'ನೀಲಿ',
    },
  };

  String _t(String key) {
    final lang = widget.language;
    return (_strings[lang] ?? _strings['en']!)[key]!;
  }

  // ── State ─────────────────────────────────────────────────────────────────
  int _current = 0;

  // SATURN scoring: count errors on scored items (indices 3–14 = 12 items).
  // Warm-up items (0–2) do NOT affect the score.
  // 0 errors → 3 pts | 1 → 2 pts | 2 → 1 pt | 3+ → 0 pts
  int _errors = 0;

  bool _showFeedback = false;
  bool _lastCorrect  = false;

  static const int _warmupCount = 3;

  int _errorsToScore(int errors) {
    if (errors == 0) return 3;
    if (errors == 1) return 2;
    if (errors == 2) return 1;
    return 0;
  }

  final _colorKeys = ['red', 'green', 'blue'];

  void _onChoice(String chosenKey) {
    if (_showFeedback) return;
    final correct = chosenKey == _items[_current].correctKey;
    setState(() {
      _showFeedback = true;
      _lastCorrect  = correct;
      // Only count errors on the 12 scored (non-warmup) items
      if (!correct && _current >= _warmupCount) _errors++;
    });
    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      setState(() {
        _showFeedback = false;
        _current++;
      });
      if (_current >= _items.length) widget.onComplete(_errorsToScore(_errors));
    });
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_t('appBarTitle')),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (!mounted) return;
                // Unanswered scored items each count as 1 error
                final remaining = _items.length - _current;
                final remainingScored = _current < _warmupCount
                    ? _items.length - _warmupCount
                    : remaining;
                final totalErrors = _errors + remainingScored;
                widget.onComplete(_errorsToScore(totalErrors));
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: _showingInstructions ? _buildInstructions() : _buildTaskBody(),
      ),
    );
  }

  Widget _buildInstructions() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 24),
          const Icon(Icons.color_lens_outlined, size: 64, color: Colors.orange),
          const SizedBox(height: 24),
          Text(
            _t('instruction'),
            style: const TextStyle(fontSize: 20, height: 1.6),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Center(
            child: PlayAudioButton(
              textToRead: _t('instruction'),
              language: widget.language,
              label: 'Read Instructions',
            ),
          ),
          const SizedBox(height: 40),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => setState(() => _showingInstructions = false),
              child: Text(_t('begin'), style: const TextStyle(fontSize: 22)),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildTaskBody() {
    if (_current >= _items.length) return const SizedBox.shrink();
    final item = _items[_current];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
          child: Text(
            '${_current + 1} / ${_items.length}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, color: Colors.grey),
          ),
        ),
        Expanded(
          flex: 3,
          child: Align(
            alignment: const Alignment(0, -0.2),
            child: Text(
              _t(item.wordKey),
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 80,
                fontWeight: FontWeight.bold,
                color: item.ink,
              ),
            ),
          ),
        ),
        Container(
          height: 56,
          margin: const EdgeInsets.symmetric(horizontal: 24),
          decoration: _showFeedback
              ? BoxDecoration(
                  color: _lastCorrect
                      ? Colors.green.shade100
                      : Colors.red.shade100,
                  borderRadius: BorderRadius.circular(12),
                )
              : null,
          alignment: Alignment.center,
          child: _showFeedback
              ? Text(
                  _lastCorrect ? '✓  Correct' : '✗  Wrong',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: _lastCorrect
                        ? Colors.green.shade800
                        : Colors.red.shade800,
                  ),
                )
              : null,
        ),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
          child: Row(
            children: _colorKeys.map((key) {
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      side: const BorderSide(color: Colors.black, width: 2),
                      padding: const EdgeInsets.symmetric(vertical: 22),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: _showFeedback ? null : () => _onChoice(key),
                    child: Text(
                      _t('btn${key[0].toUpperCase()}${key.substring(1)}'),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}

class _StroopItem {
  final String wordKey;
  final Color ink;
  final String correctKey;
  const _StroopItem({
    required this.wordKey,
    required this.ink,
    required this.correctKey,
  });
}
