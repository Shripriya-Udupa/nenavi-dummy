import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nenavi/data/question_bank.dart';
import 'package:nenavi/widgets/speakable_text.dart';
import 'package:nenavi/widgets/assessment_timer.dart';

/// Delayed number recall — patient re-enters the 4-digit number (1239)
/// they were shown earlier in the assessment.
/// Uses the native dial/number keyboard — no custom numpad.
class NumberRecallScreen extends StatefulWidget {
  final String language;
  final DateTime endTime;
  final String targetNumber;
  final Function(int score) onComplete;

  const NumberRecallScreen({
    super.key,
    required this.language,
    required this.endTime,
    required this.targetNumber,
    required this.onComplete,
  });

  @override
  State<NumberRecallScreen> createState() => _NumberRecallScreenState();
}

class _NumberRecallScreenState extends State<NumberRecallScreen> {
  final TextEditingController _controller = TextEditingController();
  bool _firstAttempt = true;

  @override
  void dispose() {
    _controller.dispose();
    TtsService.stop();
    super.dispose();
  }

  String get _instruction =>
      QuestionBank.numberRecallInstruction[widget.language] ??
      QuestionBank.numberRecallInstruction['en']!;

  void _submit() {
    final entered = _controller.text.trim();
    if (entered == widget.targetNumber) {
      widget.onComplete(_firstAttempt ? 1 : 0);
    } else {
      setState(() {
        _firstAttempt = false;
        _controller.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Incorrect, try again')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Allow the screen to resize when the keyboard appears so nothing overflows
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: const Text('Number Recall'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(40),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: AssessmentTimer(
              endTime: widget.endTime,
              onExpire: () {
                if (mounted) widget.onComplete(0);
              },
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 16),
                    Text(
                      _instruction,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: PlayAudioButton(
                        textToRead: _instruction,
                        language: widget.language,
                        label: 'Read Question',
                      ),
                    ),
                    const SizedBox(height: 32),
                    // Native number input — uses the phone's dial pad
                    TextField(
                      controller: _controller,
                      keyboardType: TextInputType.phone,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 8,
                      ),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide:
                              BorderSide(color: Colors.grey.shade400, width: 2),
                        ),
                        hintText: '- - - -',
                        hintStyle: TextStyle(
                          fontSize: 36,
                          letterSpacing: 8,
                          color: Colors.grey.shade400,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 16,
                          horizontal: 24,
                        ),
                      ),
                      maxLength: 4,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(4),
                      ],
                      onSubmitted: (_) {
                        if (_controller.text.trim().length == 4) _submit();
                      },
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            // Submit pinned at bottom, always visible
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              child: ValueListenableBuilder<TextEditingValue>(
                valueListenable: _controller,
                builder: (_, value, __) {
                  return ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      textStyle: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    onPressed: value.text.trim().length == 4 ? _submit : null,
                    child: const Text('Submit'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
