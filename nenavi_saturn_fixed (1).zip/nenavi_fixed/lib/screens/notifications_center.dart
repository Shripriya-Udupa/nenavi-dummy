import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/notification_service.dart';
import '../main.dart';
import '../localization.dart';

class NotificationsCenter extends StatefulWidget {
  const NotificationsCenter({super.key});

  @override
  State<NotificationsCenter> createState() => _NotificationsCenterState();
}

class _NotificationsCenterState extends State<NotificationsCenter> {
  final _notificationService = NotificationService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NenaviTheme.background,
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton.icon(
            onPressed: _clearAll,
            icon: const Icon(Icons.delete_sweep),
            label: const Text('Clear All'),
            style: TextButton.styleFrom(foregroundColor: Colors.white),
          ),
        ],
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _notificationService.getNotifications(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.notifications_none,
                    size: 80,
                    color: NenaviTheme.secondary.withValues(alpha: 0.3),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No notifications yet',
                    style: NenaviTheme.heading(
                      color: NenaviTheme.secondary.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
            );
          }

          final notifications = snapshot.data!;

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final notif = notifications[index];
              return _NotificationCard(
                notification: notif,
                onDismiss: () => _dismissNotification(notif['id']),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _dismissNotification(String id) async {
    await _notificationService.deleteNotification(id);
  }

  Future<void> _clearAll() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear All Notifications?'),
        content: const Text('This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: NenaviTheme.errorRed,
            ),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      await _notificationService.clearAllNotifications();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Notifications cleared')),
      );
    }
  }
}

class _NotificationCard extends StatefulWidget {
  final Map<String, dynamic> notification;
  final VoidCallback onDismiss;

  const _NotificationCard({
    required this.notification,
    required this.onDismiss,
  });

  @override
  State<_NotificationCard> createState() => _NotificationCardState();
}

class _NotificationCardState extends State<_NotificationCard> {
  late bool isRead;
  final _notificationService = NotificationService();

  @override
  void initState() {
    super.initState();
    isRead = widget.notification['read'] as bool? ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final type = widget.notification['type'] as String? ?? 'general';
    final title = widget.notification['title'] as String? ?? '';
    final message = widget.notification['message'] as String? ?? '';
    final createdAt = widget.notification['createdAt'] as Timestamp?;

    return Dismissible(
      key: Key(widget.notification['id']),
      onDismissed: (_) => widget.onDismiss(),
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 6),
        color: isRead ? NenaviTheme.cardBg : Colors.white,
        elevation: isRead ? 1 : 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _toggleRead(),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with type icon and timestamp
                Row(
                  children: [
                    _getTypeIcon(type),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: NenaviTheme.subheading().copyWith(
                              fontWeight:
                                  isRead ? FontWeight.w500 : FontWeight.bold,
                              color: isRead
                                  ? NenaviTheme.textDark
                                  : NenaviTheme.primary,
                            ),
                          ),
                          if (createdAt != null)
                            Text(
                              _formatTime(createdAt.toDate()),
                              style: NenaviTheme.small(),
                            ),
                        ],
                      ),
                    ),
                    if (!isRead)
                      Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: NenaviTheme.primary,
                          shape: BoxShape.circle,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),

                // Message
                Text(
                  message,
                  style: NenaviTheme.body(),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 12),

                // Action buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton.icon(
                      onPressed: () => widget.onDismiss(),
                      icon: const Icon(Icons.delete_outline),
                      label: const Text('Delete'),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.grey,
                      ),
                    ),
                    if (type == 'sos_alert')
                      ElevatedButton.icon(
                        onPressed: () => _viewDetails(context),
                        icon: const Icon(Icons.navigate_next),
                        label: const Text('View Alert'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _getTypeIcon(String type) {
    switch (type) {
      case 'test_reminder':
        return Icon(
          Icons.schedule,
          color: Colors.blue,
          size: 28,
        );
      case 'score_update':
        return Icon(
          Icons.assessment,
          color: Colors.green,
          size: 28,
        );
      case 'sos_alert':
        return Icon(
          Icons.emergency,
          color: Colors.red,
          size: 28,
        );
      default:
        return Icon(
          Icons.notifications,
          color: NenaviTheme.primary,
          size: 28,
        );
    }
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }

  Future<void> _toggleRead() async {
    setState(() => isRead = !isRead);
    if (isRead) {
      await _notificationService.markAsRead(widget.notification['id']);
    }
  }

  void _viewDetails(BuildContext context) {
    // Handle specific notification types
    final type = widget.notification['type'] as String? ?? '';

    if (type == 'sos_alert') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Navigate to active SOS alerts'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }
}

/// Notification badge widget for app bar
class NotificationBadge extends StatelessWidget {
  final NotificationService notificationService;

  const NotificationBadge({
    required this.notificationService,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: notificationService.getUnreadNotificationCount(),
      builder: (context, snapshot) {
        final count = snapshot.data ?? 0;

        if (count == 0) {
          return IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NotificationsCenter()),
            ),
          );
        }

        return Stack(
          children: [
            IconButton(
              icon: const Icon(Icons.notifications),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const NotificationsCenter()),
              ),
            ),
            Positioned(
              right: 0,
              top: 0,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(12),
                ),
                constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                child: Text(
                  count > 99 ? '99+' : '$count',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
