import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/emergency_sos_service.dart';
import '../localization.dart';
import '../main.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SosButton extends StatefulWidget {
  final VoidCallback? onSuccess;
  final Function(String)? onError;
  final bool compact;

  const SosButton({
    super.key,
    this.onSuccess,
    this.onError,
    this.compact = false,
  });

  @override
  State<SosButton> createState() => _SosButtonState();
}

class _SosButtonState extends State<SosButton> {
  bool _isLoading = false;
  final _sosService = EmergencySosService();
  bool _gpsReady = false;

  @override
  void initState() {
    super.initState();
    _checkGpsStatus();
  }

  Future<void> _checkGpsStatus() async {
    final serviceEnabled = await _sosService.isLocationServiceEnabled();
    final permission = await _sosService.requestLocationPermission();
    
    setState(() {
      _gpsReady = serviceEnabled && permission;
    });

    if (!_gpsReady) {
      debugPrint('GPS not ready: serviceEnabled=$serviceEnabled, permission=$permission');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: globalLanguage,
      builder: (context, lang, _) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: _isLoading
              ? _buildLoadingButton()
              : _buildActiveButton(context, lang),
        );
      },
    );
  }

 Widget _buildLoadingButton() {
  final h = widget.compact ? 44.0 : 52.0;

  return SizedBox(
    width: double.infinity,
    child: Container(
      height: h,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.red.shade400,
            Colors.red.shade600,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.red.withValues(alpha: 0.35),
            blurRadius: 16,
            spreadRadius: 1,
          ),
        ],
      ),
      child: const Center(
        child: SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            strokeWidth: 2.5,
          ),
        ),
      ),
    ),
  );
}

  Widget _buildActiveButton(BuildContext context, String lang) {
  final h = widget.compact ? 52.0 : 58.0;

  return GestureDetector(
    onTap: () => _showConfirmationDialog(context, lang),
    child: SizedBox(
      width: double.infinity,
      child: Container(
        height: h,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.red.shade400,
              Colors.red.shade700,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.red.withValues(alpha: 0.45),
              blurRadius: 18,
              spreadRadius: 2,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.emergency,
              color: Colors.white,
              size: 22,
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                Localization.get('emergency_sos', lang),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Georgia',
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

  void _showConfirmationDialog(BuildContext context, String lang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          Localization.get('emergency_sos', lang),
          style: NenaviTheme.heading(),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.warning_amber_rounded,
              color: Colors.red.shade600,
              size: 48,
            ),
            const SizedBox(height: 16),
            Text(
              Localization.get('sos_confirmation', lang),
              style: NenaviTheme.body(),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  Text(
                    //'⚠️ Your caregiver and emergency contact will be notified immediately.',
                    Localization.get('sos_message2', lang),
                    style: NenaviTheme.small(color: Colors.orange.shade900),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _gpsReady ? Colors.green.shade50 : Colors.red.shade50,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      _gpsReady
                          ? '✓ Location will be sent automatically'
                          : '⚠️ Location permission required - please enable GPS',
                      style: NenaviTheme.small(
                        color: _gpsReady ? Colors.green.shade700 : Colors.red.shade700,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          if (!_gpsReady)
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _checkGpsStatus();
                _showGpsSettingsPrompt(context, lang);
              },
              child: Text('Enable GPS', style: TextStyle(color: Colors.blue)),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(Localization.get('cancel', lang)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.shade600,
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
              _triggerSos();
            },
            child: Text(
              Localization.get('yes_send_alert', lang),
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showGpsSettingsPrompt(BuildContext context, String lang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('📍 Location Permission Required'),
        content: const Text(
          'Nenavi needs location access for Emergency SOS to send your position to your caregiver.\n\n'
          'Tap "Open App Settings" below, then:\n'
          '1. Tap Permissions\n'
          '2. Tap Location\n'
          '3. Select "Allow only while using the app"',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings(); // opens Nenavi's own App Settings page
            },
            child: const Text('Open App Settings'),
          ),
        ],
      ),
    );
  }

  Future<void> _triggerSos() async {
    setState(() => _isLoading = true);

    try {
      final alertId = await _sosService.triggerSosAlert(context: context);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Emergency alert sent! Caregiver has been notified.',
              style: NenaviTheme.body(color: Colors.white),
            ),
            backgroundColor: Colors.green.shade600,
            duration: const Duration(seconds: 3),
          ),
        );

        widget.onSuccess?.call();

        // Show status screen
        if (alertId != null) {
          _showSosStatusScreen(alertId);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error: ${e.toString()}',
              style: NenaviTheme.body(color: Colors.white),
            ),
            backgroundColor: Colors.red.shade600,
            duration: const Duration(seconds: 3),
          ),
        );

        widget.onError?.call(e.toString());
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSosStatusScreen(String alertId) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      builder: (context) => SosStatusSheet(alertId: alertId),
    );
  }
}

class SosStatusSheet extends StatefulWidget {
  final String alertId;

  const SosStatusSheet({
    required this.alertId,
    super.key,
  });

  @override
  State<SosStatusSheet> createState() => _SosStatusSheetState();
}

class _SosStatusSheetState extends State<SosStatusSheet> {
  final _sosService = EmergencySosService();
  late Stream<Map<String, dynamic>?> _alertStream;

  @override
  void initState() {
    super.initState();
    _alertStream = _sosService.watchSosAlert(widget.alertId);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: globalLanguage,
      builder: (context, lang, _) {
        return StreamBuilder<Map<String, dynamic>?>(
          stream: _alertStream,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return _buildLoadingSheet();
            }

            final alert = snapshot.data;
            if (alert == null) {
              return _buildErrorSheet(lang);
            }

            return _buildStatusSheet(alert, lang);
          },
        );
      },
    );
  }

  Widget _buildLoadingSheet() {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 16),
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          Text(
            'Sending emergency alert...',
            style: NenaviTheme.body(),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorSheet(String lang) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.error_outline,
            color: NenaviTheme.errorRed,
            size: 48,
          ),
          const SizedBox(height: 16),
          Text(
            'Error sending alert',
            style: NenaviTheme.heading(),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text(Localization.get('close', lang)),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusSheet(Map<String, dynamic> alert, String lang) {
    final status = alert['status'] as String? ?? 'pending';
    final acknowledgedAt = alert['acknowledgedAt'] as Timestamp?;
    final locationObtained = alert['locationObtained'] as bool? ?? false;
    final latitude = alert['latitude'] as double?;
    final longitude = alert['longitude'] as double?;

    return Container(
      padding: const EdgeInsets.all(24),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Status indicator
            _buildStatusIndicator(status, lang),
            const SizedBox(height: 24),

            // Alert info
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: NenaviTheme.cardBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Emergency Alert Status',
                    style: NenaviTheme.subheading(),
                  ),
                  const SizedBox(height: 12),
                  _buildStatusRow('Status:', status.toUpperCase()),
                  const SizedBox(height: 8),
                  // Location status
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: locationObtained ? Colors.green.shade50 : Colors.orange.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: locationObtained ? Colors.green : Colors.orange,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              locationObtained ? Icons.location_on : Icons.location_off,
                              color: locationObtained ? Colors.green : Colors.orange,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              locationObtained ? 'Location Shared ✓' : 'Location Pending',
                              style: TextStyle(
                                color: locationObtained ? Colors.green.shade700 : Colors.orange.shade700,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        if (locationObtained && latitude != null && longitude != null) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Coordinates: $latitude, $longitude',
                            style: TextStyle(
                              color: Colors.green.shade700,
                              fontSize: 12,
                            ),
                          ),
                        ] else if (!locationObtained) ...[
                          const SizedBox(height: 8),
                          Text(
                            'GPS location unavailable. Manual assistance may be needed.',
                            style: TextStyle(
                              color: Colors.orange.shade700,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (acknowledgedAt != null)
                    _buildStatusRow(
                      'Acknowledged:',
                      'Yes',
                      color: Colors.green,
                    ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Action buttons
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.close),
                label: Text(Localization.get('close', lang)),
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusIndicator(String status, String lang) {
  if (status == 'pending') {
    return Column(
      children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: const Duration(seconds: 1),
          builder: (context, value, _) {
            return Icon(
              Icons.notification_important,
              color: Colors.red,
              size: 60 + (value * 10),
            );
          },
        ),
        const SizedBox(height: 12),
        Text(
          Localization.get('sent_alert', lang),
          style: NenaviTheme.heading(color: Colors.red),
        ),
      ],
    );
  } else if (status == 'acknowledged') {
    return Column(
      children: [
        const Icon(
          Icons.check_circle,
          color: Colors.green,
          size: 60,
        ),
        const SizedBox(height: 12),
        Text(
          Localization.get('alert_acknowledged', lang),
          style: NenaviTheme.heading(color: Colors.green),
        ),
        const SizedBox(height: 8),
        Text(
          Localization.get('caregiver_aware', lang),
          style: NenaviTheme.body(color: NenaviTheme.secondary),
          textAlign: TextAlign.center,
        ),
      ],
    );
  } else {
    return Column(
      children: [
        const Icon(
          Icons.check_circle_outline,
          color: Colors.blue,
          size: 60,
        ),
        const SizedBox(height: 12),
        Text(
          Localization.get('resolved', lang),
          style: NenaviTheme.heading(color: Colors.blue),
        ),
      ],
    );
  }
}

  Widget _buildStatusRow(String label, String value, {Color color = Colors.black}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: NenaviTheme.body()),
        Text(
          value,
          style: NenaviTheme.body(color: color).copyWith(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Future<void> _cancelSos(String lang) async {
    try {
      await _sosService.cancelSosAlert(widget.alertId);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Emergency alert cancelled'),
            backgroundColor: Colors.orange.shade600,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: NenaviTheme.errorRed,
        ),
      );
    }
  }
}