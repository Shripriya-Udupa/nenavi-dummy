import 'package:flutter/material.dart';

/// Helper widget to show SOS contact selection dialogs
class SosDialogHelper {
  /// Show bottom sheet for sending SOS to a contact
  /// Let patient pick WhatsApp or SMS with clear availability status
  static Future<void> showSosContactDialog({
    required BuildContext context,
    required String label,        // "Caregiver" / "Emergency Contact"
    required String phone,
    required bool whatsappAvailable,
    required VoidCallback onWhatsAppPressed,
    required VoidCallback onSmsPressed,
  }) async {
    if (!context.mounted) return;

    await showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Send alert to $label',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            Text(
              phone,
              style: const TextStyle(fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),

            // ── WhatsApp button ────────────────────────────────────────
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: whatsappAvailable
                    ? const Color(0xFF25D366)
                    : Colors.grey.shade300,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(58),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                textStyle: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              icon: const Icon(Icons.chat, size: 24),
              label: Text(whatsappAvailable
                  ? 'Send via WhatsApp'
                  : 'WhatsApp not available'),
              onPressed: whatsappAvailable
                  ? () {
                      Navigator.pop(ctx);
                      onWhatsAppPressed();
                    }
                  : null,
            ),
            const SizedBox(height: 12),

            // ── SMS button ─────────────────────────────────────────────
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1565C0),
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(58),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                textStyle: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              icon: const Icon(Icons.sms, size: 24),
              label: const Text('Send via SMS'),
              onPressed: () {
                Navigator.pop(ctx);
                onSmsPressed();
              },
            ),

            const SizedBox(height: 8),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text(
                'Skip this contact',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
